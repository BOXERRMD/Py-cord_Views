from enum import Enum


class ProcessMessage(Enum):

    ADD_BOT = "add bot"
    RUN_ALL = "run all"
