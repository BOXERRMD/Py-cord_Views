from typing import TypeVar
from discord.ui import Button, Select, Modal

T_views = TypeVar('T_views', Button, Select)
